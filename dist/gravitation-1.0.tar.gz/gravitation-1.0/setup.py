from setuptools import setup

setup(
    name='gravitation',
    version='1.0',
    description='This module calculate gravitational force',
    author='SFGP',
    author_email='sandraf.gpgp@gmail.com',
    url='https://github.com/sandraGonzalezP',
    py_modules=['gravitation']

)
